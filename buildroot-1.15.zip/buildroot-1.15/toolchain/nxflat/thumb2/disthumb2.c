/***********************************************************************
 * toolchain/nxflat/thumb2/disasm.c
 * ARM Thumb2 Disassembler
 *
 *   Copyright (C) 2009 Gregory Nutt. All rights reserved.
 *   Author: Gregory Nutt <gnutt@nuttx.org>
 *
 ***********************************************************************/

#include <stdio.h>
#include <sys/types.h>

int print_insn_arm(u_int32_t pc, FILE *stream, u_int32_t given)
{
  return -1;
}
